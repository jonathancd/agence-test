@extends('layouts.app')


@section('content')
	
	
	@include('sections.filter')
	

	@include('sections.consultores')

	
	@include('sections.relatorios')
	
	
	@include('sections.relatorios')


	@include('sections.bar_chart')


	@include('sections.pizza_chart')
	

@endsection