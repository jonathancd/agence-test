<footer class="py-2">
	  	<div class="text-center">© 2019 Copyright:
	    	<span> <strong>Jonathan Cuotto.</strong></span>
	  	</div>
	</footer>
</div>