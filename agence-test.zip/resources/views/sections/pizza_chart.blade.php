<section id="section-grafica-pizza" class="mt-5 d-none">
	<div id="pizza-container" class="container">
		<canvas id="pizza-chart" width="800" height="450"></canvas>
	</div>
</section>