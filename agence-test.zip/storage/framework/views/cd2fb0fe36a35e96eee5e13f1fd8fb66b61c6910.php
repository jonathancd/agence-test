<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

	<!-- Css -->

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/toastr.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/Chart.css')); ?>" rel="stylesheet">

	<!-- Scripts -->

	<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	
	<script src="<?php echo e(asset('js/moment.js')); ?>"></script>

	<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>

	<script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>

</head>
<body>

	<div id="app">

		<div id="app-container">

			<?php echo $__env->make('layouts._partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
			<?php echo $__env->yieldContent('content'); ?>

			<?php echo $__env->make('layouts._partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			
		</div>
	</div>
	
	<script>
		const url = "<?php echo e(url('/')); ?>";
	</script>

	<script src="<?php echo e(asset('js/app.js')); ?>"></script>
	
</body>
</html><?php /**PATH C:\xampp\htdocs\agence-test\resources\views/layouts/app.blade.php ENDPATH**/ ?>