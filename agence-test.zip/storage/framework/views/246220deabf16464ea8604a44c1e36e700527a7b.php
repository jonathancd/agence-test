<section id="section-relatorios" class="mt-5">
	<div id="relatorios-container" class="container"></div>
</section><?php /**PATH C:\xampp\htdocs\agence-test\resources\views/sections/relatorios.blade.php ENDPATH**/ ?>