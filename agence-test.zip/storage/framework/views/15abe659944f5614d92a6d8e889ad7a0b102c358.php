<section id="section-grafica-bar" class="mt-5 d-none">
	<div id="grafica-container" class="container">
		<canvas id="bar-chart" width="800" height="450"></canvas>
	</div>
</section><?php /**PATH C:\xampp\htdocs\agence-test\resources\views/sections/bar_chart.blade.php ENDPATH**/ ?>